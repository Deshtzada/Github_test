const icons = document.querySelectorAll('.social-links a');

icons.forEach(icon => {
  icon.addEventListener('mouseover', () => {
    console.log('Você passou o mouse sobre o ícone de ' + icon.classList[1]);
  });
});